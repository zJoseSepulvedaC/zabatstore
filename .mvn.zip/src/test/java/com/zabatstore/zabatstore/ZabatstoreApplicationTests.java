package com.zabatstore.zabatstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZabatstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}

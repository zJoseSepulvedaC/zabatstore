package com.zabatstore.zabatstore.controller;

import com.zabatstore.zabatstore.model.Perfil;
import com.zabatstore.zabatstore.model.Usuario;
import com.zabatstore.zabatstore.repository.PerfilRepository;
import com.zabatstore.zabatstore.repository.UsuarioRepository;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/perfil")
public class PerfilController {

    private final PerfilRepository perfilRepo;
    private final UsuarioRepository usuarioRepo;

    public PerfilController(PerfilRepository perfilRepo, UsuarioRepository usuarioRepo) {
        this.perfilRepo = perfilRepo;
        this.usuarioRepo = usuarioRepo;
    }

    @GetMapping
    public String ver(@AuthenticationPrincipal Object principal, Model model) {
        // Obtener el "username" del principal, sea Usuario o UserDetails
        String email = null;
        if (principal instanceof Usuario u) {
            email = u.getEmail();
        } else if (principal instanceof UserDetails ud) {
            email = ud.getUsername();
        } else if (principal != null) {
            email = principal.toString();
        }

        if (email == null || email.isBlank()) {
            // No hay usuario válido -> salir limpiamente
            return "redirect:/logout?error=auth";
        }

        var userOpt = usuarioRepo.findByEmail(email);
        if (userOpt.isEmpty()) {
            // Usuario autenticado no está en BD (p.ej. fue borrado)
            return "redirect:/logout?error=missing";
        }
        var user = userOpt.get();

        // Traer o crear el perfil sin guardar aún
        Perfil perfil = perfilRepo.findByUsuario(user).orElseGet(() -> {
            Perfil p = new Perfil();
            p.setUsuario(user);
            return p;
        });

        model.addAttribute("perfil", perfil);
        return "perfil";
    }

    @PostMapping
    public String guardar(@ModelAttribute("perfil") Perfil perfil,
                          @AuthenticationPrincipal Object principal) {

        // Igual que arriba: obtener email de forma segura
        String email = null;
        if (principal instanceof Usuario u) {
            email = u.getEmail();
        } else if (principal instanceof UserDetails ud) {
            email = ud.getUsername();
        } else if (principal != null) {
            email = principal.toString();
        }
        if (email == null || email.isBlank()) return "redirect:/logout?error=auth";

        var user = usuarioRepo.findByEmail(email).orElse(null);
        if (user == null) return "redirect:/logout?error=missing";

        // Asegurar asociación y actualizar si ya existe
        perfil.setUsuario(user);
        perfilRepo.findByUsuario(user).ifPresent(p -> perfil.setId(p.getId()));

        perfilRepo.save(perfil);
        return "redirect:/perfil";
    }
}

INSERT INTO maquinaria (id, tipo, ubicacion, disponible_desde, precio_diario, marca, anio, capacidad, mantenciones, condiciones, medios_pago)
VALUES
  (1,'Tractor','Talca','2025-01-01', 80000,'John Deere',2018,'120HP','Cambio aceites 2024','Min 2 días','Transferencia'),
  (2,'Cosechadora','Chillán','2024-12-15', 150000,'New Holland',2020,'6000kg','Full','Con contrato','Efectivo/Transf');
